// PHASE 0 — Messages de remerciement localisés
//
// Rotation horaire pour rendre le "merci" chaleureux et varié d'une visite à
// l'autre. Utilisé par `useLocalizedThankYou` après envoi d'un formulaire.

export type ThankYou = {
  lang: 'fr' | 'ar' | 'zh' | 'en' | 'wo' | 'ff';
  text: string;
  region: string;
};

export const THANK_YOU: ThankYou[] = [
  { lang: 'fr', text: 'Merci, votre message est bien arrivé chez Couture Colombe et Merceries 🤍', region: 'BJ' },
  { lang: 'ar', text: 'شكراً، تم استلام رسالتكم في Couture Colombe et Merceries 🤍', region: 'MA' },
  { lang: 'zh', text: '谢谢，您的留言已收到 — Couture Colombe et Merceries 工作室', region: 'CN' },
  { lang: 'en', text: 'Thank you, your message reached Couture Colombe et Merceries 🤍', region: 'FR' },
  { lang: 'wo', text: 'Jërëjëf, sa xibaar bi dellu ci Couture Colombe et Merceries 🤍', region: 'SN' },
  { lang: 'ff', text: 'A jaaraama, kaɓirgal maaɓe heɓii Couture Colombe et Merceries 🤍', region: 'BF' },
];
