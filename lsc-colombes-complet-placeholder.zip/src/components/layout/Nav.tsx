import { useEffect, useState } from "react";
import { Link, NavLink } from "react-router-dom";
import { Scissors, Settings2 } from "lucide-react";
import { cn } from "@/utils/cn";
import { trackCtaClick } from "@/utils/api";
import { SmartImage } from "@/components/ui/SmartImage";
import { ConnectionStatusIcon } from "@/components/ui/ConnectionStatusIcon";
import { NotificationBell } from "@/components/notifications/NotificationBell";

const links = [
  { to: "/", label: "Accueil" },
  { to: "/services", label: "Services" },
  { to: "/formation", label: "Formation" },
  { to: "/inspirations", label: "Inspirations" },
  { to: "/contact", label: "Contact" },
];

/**
 * Texte du bandeau header — demandé explicitement par le client :
 *   - Titre      : "Couture Colombe et Merceries" (toujours entier)
 *   - Sous-titre : les AUTORISATIONS officielles, pour la crédibilité
 *     immédiate (les numéros complets vivent en mentions légales & footer)
 */
const BAND_TITLE = "Couture Colombe et Merceries";
const BAND_SUBTITLE = "✓ IFU 0202394907200 · RCCM RB/PNO/26 A 129215";

export function Nav() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav
      className={cn(
        "fixed top-0 left-0 right-0 z-40 transition-all duration-500",
        scrolled
          ? "lsc-glass-strong shadow-[0_10px_30px_-14px_rgba(60,38,20,0.25)] py-1.5"
          : "bg-gradient-to-b from-white/85 via-white/55 to-white/0 backdrop-blur-sm py-2.5",
      )}
      style={scrolled ? { borderBottom: "1px solid transparent", borderImage: "linear-gradient(90deg, transparent, var(--color-gold-thread), transparent) 1" } : undefined}
    >
      <div className="max-w-7xl mx-auto px-3 sm:px-5 lg:px-8">
        <div className="flex items-center justify-between gap-3">
          <Link to="/" className="flex items-center gap-2.5 sm:gap-3 group min-w-0">
            <div
              className={cn(
                "rounded-full overflow-hidden shrink-0 transition-all duration-300 group-hover:scale-105",
                // 🛡️ Badge royal : grand médaillon qui dépasse sous le bandeau,
                // puis se resserre joliment dès qu'on défile.
                scrolled
                  ? "w-11 h-11 sm:w-12 sm:h-12"
                  : "w-[60px] h-[60px] sm:w-16 sm:h-16 -mb-7 sm:-mb-9",
              )}
              style={{
                border: "3px solid var(--color-citron)",
                boxShadow: "0 8px 22px rgba(92,46,12,0.38), 0 0 0 3px rgba(201,168,124,0.45)",
              }}
            >
              <SmartImage
                src="/images/logo.webp"
                alt="Couture Colombe et Merceries"
                className="w-full h-full object-cover"
                onError={(e) => {
                  const el = e.currentTarget as HTMLImageElement;
                  el.style.display = "none";
                  (el.parentElement?.querySelector("[data-fallback-logo]") as HTMLElement | null)?.style.setProperty(
                    "display",
                    "flex",
                  );
                }}
              />
              <span
                data-fallback-logo
                className="absolute inset-0 items-center justify-center text-[var(--color-orange)]"
                style={{ display: "none" }}
                aria-hidden="true"
              >
                <Scissors className="w-5 h-5" />
              </span>
            </div>

            <div className="leading-tight min-w-0 group">
              <p
                className={cn(
                  "font-bold tracking-wide leading-[1.08] whitespace-normal break-words transition-all duration-300",
                  scrolled ? "text-[13px] sm:text-sm md:text-base" : "text-sm sm:text-base md:text-lg",
                )}
                style={{
                  fontFamily: "var(--font-display)",
                  color: "var(--color-ink)",
                }}
              >
                {BAND_TITLE}
              </p>
              <p
                className={cn(
                  "whitespace-normal break-words font-medium transition-all duration-300",
                  scrolled ? "text-[10px] sm:text-[11px]" : "text-[11px] sm:text-xs md:text-sm",
                )}
                style={{
                  color: "var(--color-feuille-f, #558B2F)",
                  letterSpacing: "0.02em",
                }}
              >
                {BAND_SUBTITLE}
              </p>
            </div>
          </Link>

          <div className="hidden md:flex items-center gap-7">
            {links.map((l) => (
              <NavLink
                key={l.to}
                to={l.to}
                end={l.to === "/"}
                className={({ isActive }) =>
                  cn(
                    "relative text-sm font-medium transition-colors py-1",
                    isActive ? "text-[var(--color-ink)]" : "text-[var(--color-ink-soft)] hover:text-[var(--color-ink)]",
                  )
                }
              >
                {({ isActive }) => (
                  <>
                    {l.label}
                    <span
                      className={cn(
                        "absolute left-0 -bottom-0.5 h-[2px] rounded-full transition-all duration-300",
                        isActive ? "w-full" : "w-0",
                      )}
                      style={{ backgroundColor: "var(--color-citron-d)" }}
                    />
                  </>
                )}
              </NavLink>
            ))}
            <Link
              to="/services"
              onClick={() => trackCtaClick("nav_commander")}
              className="relative overflow-hidden px-5 py-2.5 rounded-full text-sm font-semibold text-white bg-[linear-gradient(180deg,#E85454_0%,var(--color-citron)_40%,var(--color-citron-d)_130%)] !text-white shadow-[0_8px_20px_-8px_rgba(209,35,42,0.6)] transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_14px_28px_-8px_rgba(209,35,42,0.7)] hover:brightness-[1.04] active:translate-y-0 active:scale-[0.97] lsc-shine-sweep"
            >
              Commander
            </Link>
            <ConnectionStatusIcon size="md" withLabel />
            <NotificationBell size="md" />
            <Link
              to="/parametres"
              className="inline-flex items-center justify-center min-h-[40px] min-w-[40px] rounded-full border border-[var(--color-line)] bg-white/80 text-[var(--color-ink)] hover:border-[var(--color-citron)] transition-colors"
              aria-label="Ouvrir les paramètres"
            >
              <Settings2 className="w-4 h-4" />
            </Link>
          </div>

          <div className="md:hidden flex items-center gap-2 shrink-0">
            <ConnectionStatusIcon size="sm" withLabel={false} />
            <NotificationBell size="sm" />
            <Link
              to="/parametres"
              className="inline-flex items-center justify-center min-h-[44px] min-w-[44px] rounded-lg border border-[var(--color-line)] bg-white/85 text-[var(--color-ink)] hover:border-[var(--color-citron)]"
              aria-label="Paramètres"
            >
              <Settings2 className="w-5 h-5" />
            </Link>
            {/* 🪡 Plus de bouton « 3 barres » : la navigation vit déjà
                dans la barre du bas (Accueil…Menu) — le bandeau respire. */}
          </div>
        </div>

        {/* Menu déroulant mobile retiré — remplacé définitivement par la barre du bas. */}
      </div>
    </nav>
  );
}
